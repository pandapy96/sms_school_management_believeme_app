import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'usermamagerment.dart';

class UserProfileScreen extends StatelessWidget {
  final UserManager userManager;

  UserProfileScreen({required this.userManager});

  @override
  Widget build(BuildContext context) {
    final user = userManager.currentUser;

    return Scaffold(
      appBar: AppBar(
        title: Text('User Profile'),
      ),
      body: user == null
          ? Center(child: Text('No user logged in'))
          : Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Center(
                    child: CircleAvatar(
                      radius: 50,
                      backgroundImage: NetworkImage(user.profilePictureUrl),
                    ),
                  ),
                  SizedBox(height: 16),
                  Text(
                    'Name: ${user.name}',
                    style: TextStyle(fontSize: 18),
                  ),
                  SizedBox(height: 8),
                  Text(
                    'Email: ${user.email}',
                    style: TextStyle(fontSize: 18),
                  ),
                  SizedBox(height: 16),
                  ElevatedButton(
                    onPressed: () {
                      userManager.logout();
                      Navigator.of(context).pop();
                    },
                    child: Text('Logout'),
                  ),
                ],
              ),
            ),
    );
  }
}