import 'package:flutter/material.dart';
import 'package:sms_managerment_believeme_school/Setting/setting_dashborad.dart';

class Registermanagerment extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true, // Prevents overflow due to keyboard
      backgroundColor: const Color(0xFF0D1321),
      appBar: AppBar(
        backgroundColor: Color.fromARGB(255, 10, 10, 24),
        iconTheme: IconThemeData(color: Colors.white),
        title: Text('ចុះឈ្មោះសិស្សសម្រាប់សិស្សថ្មី',
        style: TextStyle(
          color: Colors.white,
          fontSize: 18,
          fontWeight: FontWeight.w100,
        ),
      ),
      actions: [
          IconButton(
            icon: Icon(
              Icons.notifications,
              color: const Color.fromARGB(255, 255, 255, 255),
              size: 25,
          ),
            onPressed: () {
            },
          ),
          IconButton(
            icon: Icon(
              Icons.settings,
              color: const Color.fromARGB(255, 255, 255, 255),
              size: 25,
          ),
            onPressed: () {
              Navigator.push(context,
                    MaterialPageRoute(builder: (context) => SettingsPage()));
            },
          ),
        ],
      ),
      body: Center(child: Text('User Management Page11',
        style: TextStyle(
          color: Colors.white,
        ),
      )),
    );
  }
}

class ProfileForm extends StatefulWidget {
  @override
  _ProfileFormState createState() => _ProfileFormState();
}

class _ProfileFormState extends State<ProfileForm> {
  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(
        children: [
          TextFormField(
            decoration: InputDecoration(labelText: 'Name'),
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'Please enter your name';
              }
              return null;
            },
          ),
          ElevatedButton(
            onPressed: () {
              if (_formKey.currentState?.validate() ?? false) {
                print('Form is valid');
              }
            },
            child: Text('Submit'),
          ),
        ],
      ),
    );
  }
}
