import 'package:flutter/material.dart';

class Scoremanagerment extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true, // Prevents overflow due to keyboard
      backgroundColor: const Color(0xFF0D1321),
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.white),
        backgroundColor: Color.fromARGB(255, 10, 10, 24),
        title: 
        Text(
          'ប្រតិបត្តិពិន្ទុរបស់សិស្ស',
          style: 
          TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w100,
            fontSize: 18,
          ),
        ),
      ),
      body: LayoutBuilder(
        builder: (context, constraints) {
          if (constraints.maxWidth > 600) {
            return WebView();
          } else {
            return MobileView();
          }
        },
      ),
    );
  }
}

class MobileView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text("Mobile View"),
    );
  }
}

class WebView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text("Web View"),
    );
  }
}
class User {
  final String name;
  final String email;
  final String profilePictureUrl;

  User({required this.name, required this.email, required this.profilePictureUrl});
}

class UserManager {
  User? _currentUser;

  User? get currentUser => _currentUser;

  void login(String name, String email, String profilePictureUrl) {
    _currentUser = User(name: name, email: email, profilePictureUrl: profilePictureUrl);
  }

  void logout() {
    _currentUser = null;
  }
}