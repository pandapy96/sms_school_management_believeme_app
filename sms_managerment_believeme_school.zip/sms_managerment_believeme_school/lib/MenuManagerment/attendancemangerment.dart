import 'package:flutter/material.dart';

class Attendancemangerment extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true, // Prevents overflow due to keyboard
      backgroundColor: const Color(0xFF0D1321),
      
      appBar:
        AppBar(
          iconTheme: IconThemeData(color: Colors.white),
            backgroundColor: Color.fromARGB(255, 10, 10, 24),
            title: 
              Text(
                'ការគ្រប់គ្រងវត្តមាន',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.w100,
                  ),
                )),
      
      body: 
      Center(child: Text('Attendance Page',
        style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                  ),
      
      )),
    );
  }
}