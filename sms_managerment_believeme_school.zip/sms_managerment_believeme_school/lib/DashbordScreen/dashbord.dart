import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:sms_managerment_believeme_school/Home%20Page%20Screen/intro_screen.dart';
import 'package:sms_managerment_believeme_school/MenuManagerment/attendancemangerment.dart';
import 'package:sms_managerment_believeme_school/MenuManagerment/listpaymentmanagerment.dart';
import 'package:sms_managerment_believeme_school/MenuManagerment/liststudentmanagerment.dart';
import 'package:sms_managerment_believeme_school/MenuManagerment/paymentmanagerment.dart';
import 'package:sms_managerment_believeme_school/MenuManagerment/profile_user_screen.dart';
import 'package:sms_managerment_believeme_school/MenuManagerment/registermanagerment.dart';
import 'package:sms_managerment_believeme_school/MenuManagerment/reportmanagerment.dart';
import 'package:sms_managerment_believeme_school/MenuManagerment/schedulemanagernent.dart';
import 'package:sms_managerment_believeme_school/MenuManagerment/scoremanagerment.dart';
import 'package:sms_managerment_believeme_school/MenuManagerment/usermamagerment.dart';
import 'package:sms_managerment_believeme_school/Setting/setting_dashborad.dart';

class DashboardPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Dashboard'),
      ),
      body: Center(
        child: Text('Welcome to the Dashboard'),
      ),
    );
  }
}

class WallpaperPage extends StatelessWidget {
  final List<String> featuredImages = [
    'assets/logos/beliveme.png',
    'assets/logos/beliveme.png',
    'assets/logos/beliveme.png',
  ];
  final List<Map<String, String>> categories = [
    {'title': 'Anime', 'image': 'assets/logos/beliveme.png'},
    {'title': 'Cars', 'image': 'assets/logos/beliveme.png'},
    {'title': 'Nature', 'image': 'assets/logos/beliveme.png'},
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Wallpapers'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Featured Wallpapers (Auto-scrolling Carousel)
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(
                'Wallpapers',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
            ),
            CarouselSlider(
              items: featuredImages
                  .map((image) => ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: Image.asset(
                          image,
                          fit: BoxFit.cover,
                          width: double.infinity,
                        ),
                      ))
                  .toList(),
              options: CarouselOptions(
                autoPlay: true,
                enlargeCenterPage: true,
                height: 200,
                viewportFraction: 0.9,
              ),
            ),
            // Categories
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(
                'Categories',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
            ),
            SizedBox(
              height: 120,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: categories
                    .map((category) => GestureDetector(
                          onTap: () {
                            // Navigate to the category page
                          },
                          child: Container(
                            margin: EdgeInsets.symmetric(horizontal: 8),
                            width: 100,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              image: DecorationImage(
                                image: AssetImage(category['image']!),
                                fit: BoxFit.cover,
                              ),
                            ),
                            child: Align(
                              alignment: Alignment.bottomCenter,
                              child: Container(
                                color: Colors.black54,
                                child: Text(
                                  category['title']!,
                                  style: TextStyle(color: Colors.white),
                                  textAlign: TextAlign.center,
                                ),
                              ),
                            ),
                          ),
                        ))
                    .toList(),
              ),
            ),
            // Featured Section
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(
                'Featured',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
            ),
            GridView.builder(
              physics: NeverScrollableScrollPhysics(),
              shrinkWrap: true,
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                childAspectRatio: 16 / 9,
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
              ),
              itemCount: featuredImages.length,
              itemBuilder: (context, index) {
                return ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: Image.asset(
                    featuredImages[index],
                    fit: BoxFit.cover,
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

class CardWidget extends StatelessWidget {
  final Color color;

  CardWidget({required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 150,
      width: 250,
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(16),
      ),
    );
  }
}

class RecentCard extends StatelessWidget {
  final String title;
  final Color color;

  RecentCard({required this.title, required this.color});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
      child: Container(
        height: 100,
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Align(
            alignment: Alignment.centerLeft,
            child: Text(
              title,
              style: TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

Widget _buildSectionHeader(BuildContext context, String title) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          title,
          style: TextStyle(
            fontSize: 18, 
            fontWeight: FontWeight.w100,
            color: Colors.white,  
          ),
        ),
      ],
    );
  }

  Widget _buildHorizontalList(List<Widget> items) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: items.map((item) => Padding(
          padding: const EdgeInsets.only(right: 10.0),
          child: item,
        )).toList(),
      ),
    );
  }

  Widget _buildTile(String title, Color color) {
    return Container(
      width: 150,
      height: 100,
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Center(
        child: Text(
          title,
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
  Widget _buildImageTile(String imageUrl) {
    return Container(
      width: 150,
      height: 150,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        image: DecorationImage(
          image: NetworkImage(
            'https://cdn.dribbble.com/users/275714/screenshots/3245676/gif.gif'            
          ),
          fit: BoxFit.cover,
        ),
      ),
    );
  }
  Widget _buildStatCard(String title, String count, Color color) {

    return Card(
      elevation: 2,
      child: Container(
        width: 120,
        height: 120,
        color: color,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(title, style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w300,
              fontSize: 18,
              )),
            Text(count, style: TextStyle(
              color: Colors.white, 
              fontSize: 25,
              fontWeight: FontWeight.bold,
            )),
          ],
        ),
      ),
    );
  }
