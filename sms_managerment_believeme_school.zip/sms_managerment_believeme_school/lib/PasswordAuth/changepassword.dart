import 'package:flutter/material.dart';

class Changepassword extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Change Password', 
        style: TextStyle(
          color: Colors.white,
          fontSize: 20,
        ),
        ),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        backgroundColor: Colors.pink,
      ),
      body: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: SingleChildScrollView(
          padding: EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _buildPasswordField('Old Password'),
              SizedBox(height: 16),
              _buildPasswordField('New Password'),
              SizedBox(height: 16),
              _buildPasswordField('Confirm Password'),
              SizedBox(height: 24),
              ElevatedButton(
                onPressed: () {
                  // Handle password change
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.pink,
                  padding: EdgeInsets.symmetric(vertical: 16.0),
                ),
                child: Text('Change Password', 
                  style: TextStyle(
                    fontSize: 18,
                    color: Colors.white,
                )),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildPasswordField(String hint) {
    return TextField(
      obscureText: false,
      decoration: InputDecoration(
        prefixIcon: Icon(Icons.lock),
        suffixIcon: IconButton(
          icon: Icon(Icons.visibility),
          onPressed: () {
            // Toggle password visibility
          },
        ),
        labelText: hint,
        border: OutlineInputBorder(),
      ),
    );
  }
}
