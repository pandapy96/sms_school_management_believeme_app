import 'package:flutter/material.dart';
import 'package:sms_managerment_believeme_school/DashbordScreen/dashbord.dart';
import 'package:sms_managerment_believeme_school/DeverloperPage/aboutdeverloperpage.dart';
import 'package:sms_managerment_believeme_school/DeverloperPage/aboutlicence.dart';
import 'package:sms_managerment_believeme_school/DeverloperPage/termsofservice.dart';
import 'package:sms_managerment_believeme_school/Home%20Page%20Screen/intro_video.dart';
import 'package:sms_managerment_believeme_school/MenuManagerment/registermanagerment.dart';
import 'package:sms_managerment_believeme_school/PasswordAuth/changepassword.dart';

class SettingsPage extends StatefulWidget {
  @override
  _SettingsPageState createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  // State variablesc
  bool isDarkMode = false; // Toggle for dark mode
  String userName = "";
  String email = "";

  // Handle logout
  void logout() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
          "ចាកចេញ",
          style: TextStyle(
            color: const Color.fromARGB(255, 0, 0, 0),
            fontWeight: FontWeight.w300,
          ),
        ),
        content: Text(
          "តើ​អ្នក​ប្រាកដ​ជា​ចង់ចាកចេញ មែន ឬ ទេ​ ?",
          style: TextStyle(
            fontWeight: FontWeight.w300,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context), // Cancel
            child: Text(
              "បោះបង់",
              style: TextStyle(
                fontWeight: FontWeight.w300,
              ),
            ),
          ),
          TextButton(
            onPressed: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => IntroVideo()));
              // Logic for logout can be implemented here
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text("Logged out successfully!")),
              );
            },
            child: Text(
              "ចាកចេញ",
              style: TextStyle(
                color: Colors.red,
                fontWeight: FontWeight.w300,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // Handle navigation
  void navigateTo(String screenName) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
          closeIconColor: const Color.fromARGB(255, 255, 255, 255),
          content: Text(
            "Navigating to $screenName...",
            style: TextStyle(
              color: const Color.fromARGB(255, 255, 255, 255),
            ),
          )),
    );
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(),
      home: Scaffold(
        resizeToAvoidBottomInset: true,
        backgroundColor: const Color(0xFF0D1321),
        appBar: AppBar(
          iconTheme: IconThemeData(color: Colors.white),
          backgroundColor: Color.fromARGB(255, 10, 10, 24),
          title: Text(
            "ការកំណត់",
            style: TextStyle(
              color: Colors.white,
              fontSize: 20,
              fontWeight: FontWeight.w300,
            ),
          ),
          actions: [
            IconButton(
              icon: Icon(
                Icons.notifications_active,
                color: const Color.fromARGB(255, 255, 255, 255),
                size: 25,
              ),
              onPressed: () {
                // Settings action
                // Settings action
              },
            ),
            IconButton(
              icon: Icon(
                Icons.backspace,
                color: const Color.fromARGB(255, 255, 255, 255),
                size: 25,
              ),
              onPressed: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => DashboardPage()));
                // Settings action
                // Settings action
              },
            ),
          ],
        ),
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ListTile(
                  leading: Icon(
                    Icons.person,
                    color: Colors.white,
                  ),
                  title: Text(
                    "គណនីរបស់អ្នក",
                    style: TextStyle(
                      fontSize: 18,
                      color: Colors.white,
                      fontWeight: FontWeight.w300,
                    ),
                  ),
                  onTap: () => navigateTo(
                    "បានចូលគណនីរបស់អ្នក",
                  ),
                  trailing: Icon(
                    Icons.arrow_forward_ios,
                    size: 18,
                    color: Colors.white,
                  ),
                ),
                Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            userName,
                            style: TextStyle(
                              color: const Color.fromARGB(255, 9, 255, 0),
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                          Text(
                            email,
                            style: TextStyle(
                              fontSize: 14,
                              color: const Color.fromARGB(255, 255, 255, 255),
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                Divider(height: 1),
                // Settings Form
                Text(
                  "ទូទៅ",
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w300,
                    color: Colors.white,
                  ),
                ),
                ListTile(
                  leading: Icon(
                    Icons.language_sharp,
                    color: Colors.white,
                  ),
                  title: Text(
                    "ភាសា - ភាសាខ្មែរ",
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.white,
                      fontWeight: FontWeight.w300,
                    ),
                  ),
                  onTap: () => navigateTo(
                    "Change Password",
                  ),
                  trailing: Icon(
                    Icons.arrow_forward_ios,
                    size: 16,
                    color: Colors.white,
                  ),
                ),
                /*ListTile(
                  leading: Icon(
                    Icons.dark_mode,
                    color: Colors.white,
                  ),
                  title: Text(
                    "ផ្ឬាំង-ងងឺត",
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.white,
                      fontWeight: FontWeight.w100,
                    ),
                  ),
                  onTap: () => navigateTo(
                    "Change Password",
                  ),
                  trailing: Icon(
                    Icons.arrow_forward_ios,
                    size: 16,
                    color: Colors.white,
                  ),
                ),*/
                Text(
                  "គណនី",
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w300,
                    color: Colors.white,
                  ),
                ),
                ListTile(
                  leading: Icon(
                    Icons.person,
                    color: Colors.white,
                  ),
                  title: Text(
                    "ព័ត៌មានផ្ទាល់ខ្លួន",
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.white,
                      fontWeight: FontWeight.w300,
                    ),
                  ),
                  onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => ProfileForm())),
                  trailing: Icon(
                    Icons.arrow_forward_ios,
                    size: 16,
                    color: Colors.white,
                  ),
                ),
                ListTile(
                  leading: Icon(
                    Icons.person_add,
                    color: Colors.white,
                  ),
                  title: Text(
                    "កែប្រែព័ត៌មានផ្ទាល់ខ្លួន",
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.white,
                      fontWeight: FontWeight.w300,
                    ),
                  ),
                  onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => ProfileForm())),
                  trailing: Icon(
                    Icons.arrow_forward_ios,
                    size: 16,
                    color: Colors.white,
                  ),
                ),
                Text(
                  "សន្តិសុខ",
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w300,
                    color: Colors.white,
                  ),
                ),
                ListTile(
                  leading: Icon(
                    Icons.lock,
                    color: Colors.white,
                  ),
                  title: Text(
                    "ការប្តូរពាក្រសម្ងាត់",
                    style: TextStyle(
                      fontWeight: FontWeight.w300,
                      fontSize: 16,
                      color: Colors.white,
                    ),
                  ),
                  onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => Changepassword())),
                  trailing: Icon(
                    Icons.arrow_forward_ios,
                    size: 16,
                    color: Colors.white,
                  ),
                ),
                Text(
                  "ផ្សេងៗ",
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w300,
                    color: Colors.white,
                  ),
                ),
                // Example Setting Option: Change Password
                ListTile(
                  leading: Icon(
                    Icons.article_outlined,
                    color: Colors.white,
                  ),
                  title: Text(
                    "លក្ខខណ្ឌនៃសេវាកម្ម",
                    style: TextStyle(
                      fontWeight: FontWeight.w300,
                      fontSize: 16,
                      color: Colors.white,
                    ),
                  ),
                  onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => Termsofservice())),
                  trailing: Icon(
                    Icons.arrow_forward_ios,
                    size: 16,
                    color: Colors.white,
                  ),
                ),
                // Example Setting Option: Notifications
                ListTile(
                  leading: Icon(
                    Icons.info,
                    color: Colors.white,
                  ),
                  title: Text(
                    "អាជ្ញាប័ណ្ណ",
                    style: TextStyle(
                        fontWeight: FontWeight.w300,
                        fontSize: 16,
                        color: Colors.white),
                  ),
                  onTap: () => Navigator.push(context,
                      MaterialPageRoute(builder: (context) => Aboutlicence())),
                  trailing: Icon(
                    Icons.arrow_forward_ios,
                    size: 16,
                    color: Colors.white,
                  ),
                ),
                ListTile(
                  leading: Icon(
                    Icons.developer_mode,
                    color: Colors.white,
                  ),
                  title: Text(
                    "អ្នកបង្កើតកម្មវីធី-Deverloper",
                    style: TextStyle(
                        fontWeight: FontWeight.w300,
                        fontSize: 16,
                        color: Colors.white),
                  ),
                  onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => Aboutdeverloperpage())),
                  trailing: Icon(
                    Icons.arrow_forward_ios,
                    size: 16,
                    color: Colors.white,
                  ),
                ),
                Divider(height: 32),
                // Dark Mode Toggle
                // Logout Row
                SizedBox(height: 16),
                ListTile(
                  leading: Icon(Icons.logout, color: Colors.red),
                  title: Text(
                    "ចុះចេញ",
                    style: TextStyle(
                      fontSize: 20,
                      color: Colors.red,
                      fontWeight: FontWeight.w100,
                    ),
                  ),
                  onTap: logout,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
