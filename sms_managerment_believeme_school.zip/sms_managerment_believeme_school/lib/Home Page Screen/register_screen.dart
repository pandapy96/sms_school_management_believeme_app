import 'package:flutter/material.dart';
import 'package:sms_managerment_believeme_school/Home%20Page%20Screen/forget_password.dart';
import 'package:sms_managerment_believeme_school/Home%20Page%20Screen/register_screen.dart';
import 'package:sms_managerment_believeme_school/Home%20Page%20Screen/singup_screen.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({Key? key}) : super(key: key);

  @override
  _RegisterScreenState createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _formKey = GlobalKey<FormState>();
  bool _isAnimating = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF0D1321),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
      ),
      resizeToAvoidBottomInset: true, // Prevent keyboard overflow
      backgroundColor: const Color(0xFF0D1321), // Dark background color
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Image.asset(
                    'assets/logos/beliveme.png', // Correct path to your image
                    height: 100,
                    width: 100,
                  ),
                  Text(
                    "សាលា អ៊ីហ្ស៊លកម្ពុជា\nBeliveMe School",
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 26,
                      fontWeight: FontWeight.w100,
                    ),
                  ),
                  const Text(
                    "Hey there,",
                    style: TextStyle(
                      fontSize: 18, color: Colors.grey),
                  ),
                  const SizedBox(height: 10),
                  const Text(
                    "Create an Account",
                    style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: Colors.white),
                  ),
                  const SizedBox(height: 20),
                  _buildTextField(Icons.person, "First Name"),
                  const SizedBox(height: 10),
                  _buildTextField(Icons.person, "Last Name"),
                  const SizedBox(height: 10),
                  _buildTextField(Icons.email, "Email"),
                  const SizedBox(height: 10),
                  CustomPasswordField(
                    labelText: "Password",
                  ),
                  const SizedBox(height: 10),
                  CustomPasswordField(
                    labelText: "Confirm Password",
                  ),
                  const SizedBox(height: 15),
                  Row(
                    children: [
                      Checkbox(
                        value: true,
                        onChanged: (value) {},
                        activeColor: Colors.purple,
                      ),
                      Flexible(
                        child: Text.rich(
                          TextSpan(
                            text: "By creating an account, you agree to our ",
                            style: const TextStyle(color: Colors.grey),
                            children: [
                              TextSpan(
                                text: "Conditions of Use",
                                style: const TextStyle(color: Colors.blue),
                              ),
                              const TextSpan(text: " and "),
                              TextSpan(
                                text: "Privacy Notice",
                                style: const TextStyle(color: Colors.blue),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 15),
                  AnimatedContainer(
                    duration: const Duration(seconds: 1),
                    curve: Curves.easeInOut,
                    width: _isAnimating ? 200 : double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        if (_formKey.currentState!.validate()) {
                          _handleSignUp(context);
                        } else {
                          _showAlertDialog(context);
                        }
                        setState(() {
                          _isAnimating = !_isAnimating;
                        });
                      },
                      style: ElevatedButton.styleFrom(
                        minimumSize: const Size(double.infinity, 50),
                        backgroundColor: Color.fromARGB(255, 2, 173, 102),
                      ),
                      child: const Text(
                        "Register",
                        style: TextStyle(
                            fontSize: 16,
                            color: Colors.white,
                            fontWeight: FontWeight.w700),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  const Text(
                    "មានគណនីរួចហើយ!",
                    style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w100,
                        color: Color.fromARGB(255, 0, 255, 17)),
                  ),
                  const SizedBox(height: 10),
                  GestureDetector(
                    onTap: () {
                      Navigator.push(context,MaterialPageRoute(builder: (context) => SingupScreen()));
                      print("Sign Up tapped!");
                    },
                    child: 
                    Text(
                      "Already have an account?  Login",
                      style: TextStyle(
                          fontSize: 16,
                          color: Colors.blue.shade200,
                          decoration: TextDecoration.underline,
                      ),
                    ),      
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTextField(IconData icon, String hintText) {
    return TextFormField(
      style: const TextStyle(color: Colors.white),
      decoration: InputDecoration(
        prefixIcon: Icon(icon, color: Colors.white),
        hintText: hintText,
        filled: true,
        fillColor: Color.fromARGB(255, 31, 42, 59),
        hintStyle: const TextStyle(color: Colors.grey),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide.none,
        ),
      ),
      validator: (value) {
        if (value == null || value.isEmpty) {
          return 'Please enter $hintText';
        }
        return null;
      },
    );
  }

  void _handleSignUp(BuildContext context) {
    // Connect to database or handle sign-up logic here
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Sign-Up logic goes here")),
    );
  }

  void _showAlertDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text("Error"),
          content: const Text("Please fill in all fields"),
          actions: [
            TextButton(
              child: const Text("OK"),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }
}

class CustomPasswordField extends StatefulWidget {
  final String labelText;

  const CustomPasswordField({
    Key? key,
    required this.labelText,
  }) : super(key: key);

  @override
  _CustomPasswordFieldState createState() => _CustomPasswordFieldState();
}

class _CustomPasswordFieldState extends State<CustomPasswordField> {
  bool _obscureText = true;

  void _toggleVisibility() {
    setState(() {
      _obscureText = !_obscureText;
    });
  }

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      obscureText: _obscureText,
      style: const TextStyle(color: Colors.white),
      decoration: InputDecoration(
        prefixIcon: const Icon(Icons.lock, color: Colors.white),
        suffixIcon: IconButton(
          icon: Icon(
            _obscureText ? Icons.visibility_off : Icons.visibility,
            color: Colors.white,
          ),
          onPressed: _toggleVisibility,
        ),
        hintText: widget.labelText,
        filled: true,
        fillColor: Color.fromARGB(255, 31, 42, 59),
        hintStyle: const TextStyle(color: Colors.grey),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide.none,
        ),
      ),
      validator: (value) {
        if (value == null || value.isEmpty) {
          return 'Please enter ${widget.labelText}';
        }
        return null;
      },
    );
  }
}