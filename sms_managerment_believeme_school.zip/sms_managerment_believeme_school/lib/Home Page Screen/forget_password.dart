import 'package:flutter/material.dart';
import 'package:sms_managerment_believeme_school/Home%20Page%20Screen/singup_screen.dart';


class ForgetPassword extends StatefulWidget {
  @override
  _ForgetPasswordPageState createState() => _ForgetPasswordPageState();
}

class _ForgetPasswordPageState extends State<ForgetPassword> {
  final TextEditingController _emailController = TextEditingController();

  // Simulated API Call (Replace with actual database/API connection logic)
  Future<void> sendResetInstructions() async {
    final String email = _emailController.text.trim();

    if (email.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Please enter your email')),
      );
      return;
    }

    // Simulate API request delay
    await Future.delayed(Duration(seconds: 2));

    // Simulate success response
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Reset instructions sent to $email')),
    );
  }

  @override
  Widget build(BuildContext context) {
    // Responsive layout
    // ignore: unused_local_variable
    final bool isMobile = MediaQuery.of(context).size.width < 600;

    return Scaffold(
      resizeToAvoidBottomInset: true, // Prevents overflow due to keyboard
      backgroundColor: const Color(0xFF0D1321),
      appBar: AppBar(
        backgroundColor: Color.fromARGB(255, 31, 42, 59),
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Color.fromARGB(255, 255, 255, 255)),
          onPressed: () {
            Navigator.push(context, MaterialPageRoute(builder: (context) => SingupScreen()));
            // Handle back navigation
          },
        ),
      ),
      body: Center(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  margin: EdgeInsets.only(bottom: 20), // Add margin to the bottom
                  child: Image.asset(
                    'assets/logos/beliveme.png', // Correct path to your image
                    height: 100,
                    width: 100,
                  ),
                ),
                Text(
                  'Forget Password',
                  style: TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                    color: Color.fromARGB(255, 255, 255, 255),
                  ),
                ),
                SizedBox(height: 20),
                Text(
                  'Forgot your password? That\'s okay, it happens to everyone!\nPlease provide your email to reset your password.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 16,
                    color: Color.fromARGB(255, 0, 255, 21),
                  ),
                ),
                SizedBox(height: 30),
                TextField(
                  controller: _emailController,
                  keyboardType: TextInputType.emailAddress,
                  style: TextStyle(color: Color.fromARGB(255, 255, 255, 255)),
                  decoration: InputDecoration(
                    prefixIcon: Icon(Icons.email, color: Color.fromARGB(153, 255, 255, 255)),
                    hintText: 'Email',
                    hintStyle: TextStyle(color: Color.fromARGB(153, 255, 255, 255)),
                    filled: true,
                    fillColor: Color.fromARGB(255, 31, 42, 59),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide.none,
                    ),
                  ),
                ),
                SizedBox(height: 20),
                ElevatedButton(
                  onPressed: () {
                    sendResetInstructions();
                  },
                  style: ElevatedButton.styleFrom(
                    minimumSize: Size(double.infinity, 50),
                    backgroundColor: Color.fromARGB(255, 2, 173, 102),
                  ),
                  child: Text(
                    'Send Instruction',
                    style: TextStyle(fontSize: 18, color: Color.fromARGB(255, 255, 255, 255)),
                  ),
                ),
                SizedBox(height: 50),
                Text(
                  'សាលា អ៊ីហ្ស៊លកម្ពុជា\n BeliveMe School',
                  style: TextStyle(
                    fontSize: 22,
                    color: Color.fromARGB(255, 255, 255, 255),
                    fontWeight: FontWeight.w100,
                  ),
                ),
                
              ],
            ),
          ),
        ),
      ),
    );

  }
}