import 'package:flutter/material.dart';
import 'package:sms_managerment_believeme_school/Home%20Page%20Screen/singup_screen.dart';
import 'package:video_player/video_player.dart';
import 'intro_video.dart';

class IntroPage extends StatelessWidget {
  const IntroPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return Scaffold(
      resizeToAvoidBottomInset: true, // Prevent keyboard overflow
      backgroundColor: const Color(0xFF0D1321),
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Logo
                Container(
                  width: size.width * 0.4, // Responsive width
                  height: size.width * 0.4,
                  decoration: BoxDecoration(
                    image: DecorationImage(
                      image: AssetImage(
                        'assets/logos/beliveme.png'), // Add your logo path
                      fit: BoxFit.contain,
                    ),
                  ),
                ),
                SizedBox(height: size.height * 0.05),
                // Title
                Text(
                  'សូមស្វាគមន៍ សាលា អ៊ីហ្ស៊លកម្ពុជា',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: size.width * 0.06, // Responsive font size
                    fontWeight: FontWeight.w100,
                    color: Color(0xFFF9B50A),
                  ),
                ),
                SizedBox(height: size.height * 0.01),
                // Title
                Text(
                  'Welcome to SchoolBeliveMe Application',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: size.width * 0.06, // Responsive font size
                    fontWeight: FontWeight.w600,
                    color: const Color.fromARGB(255, 208, 208, 208),
                  ),
                ),
                SizedBox(height: size.height * 0.02),
                // Content
                Text(
                  'រក្សាទំនាក់ទំនងជាមួយសាលារបស់អ្នក \nនិងគ្រប់គ្រងអ្វីគ្រប់យ៉ាងនៅចុងម្រាមដៃរបស់អ្នក។\nStay connected with your school and manage everything at your fingertips.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontWeight: FontWeight.w100,
                    fontSize: size.width * 0.04,
                    color: const Color.fromARGB(255, 181, 181, 181),
                  ),
                ),
                SizedBox(height: size.height * 0.05),
                // Continue Button
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color.fromARGB(255, 2, 173, 102),
                    padding: EdgeInsets.symmetric(
                      horizontal: size.width * 0.2,
                      vertical: size.height * 0.015,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                  ),
                  onPressed: () {
                    // Navigate to login page
                  Navigator.push(context,MaterialPageRoute(builder: (context) => SingupScreen()));
                  },
                  child: Text(
                    'Continue',
                    style: TextStyle(
                      fontSize: size.width * 0.045,
                      color: Colors.white,
                    ),
                  ),
                ),
                SizedBox(height: size.height * 0.10),
                Text('App Version: 0.2.3', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w100, color: Colors.white,),),
                SizedBox(height: size.height * 0.01),
                Text('Deverloper App By: ក្រុមសារណា', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w100, color: Colors.white,),),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class IntroScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Intro Screen'),
      ),
      body: Center(
        child: ElevatedButton(
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => IntroVideo()),
            );
          },
          child: Text('Play Intro Video'),
        ),
      ),
    );
  }
}