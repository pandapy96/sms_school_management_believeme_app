import 'package:flutter/material.dart';

class Aboutlicence extends StatelessWidget {
  const Aboutlicence({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("License Agreement",
        style: TextStyle(
          color: Colors.white,
        ),
        ),
        iconTheme: IconThemeData(color: Colors.white),
        backgroundColor: Colors.deepPurple,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Title
            const Text(
              "License Agreement",
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.deepPurple,
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              "Lead Professor: Rin Tino",
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            // Developer Info
            const Text(
              "Created By: Nou Sivyang",
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const Text(
              "Developer: Nou Sivyang",
              style: TextStyle(fontSize: 16),
            ),
            const Text(
              "Assistant Developer: Brach SiDa",
              style: TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 10),

            // License Form Section
            const Text(
              "Terms and Conditions",
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.deepPurple,
              ),
            ),
            const SizedBox(height: 10),
            Expanded(
              child: SingleChildScrollView(
                child: const Text(
                  "1. This software is developed by Nou Sivyang.\n"
                  "2. You are granted a limited, non-exclusive license to use this application.\n"
                  "3. Redistribution, modification, or resale of this application without prior consent is prohibited.\n"
                  "4. The developer holds no responsibility for any damages caused by improper use of this application.\n\n"
                  "By using this application, you agree to the above terms and conditions.",
                  style: TextStyle(fontSize: 16),
                ),
              ),
            ),

            const SizedBox(height: 20),

            // Accept Button
            Center(
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.deepPurple,
                  padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 10),
                ),
                onPressed: () {
                  // Action when user accepts the license
                  showDialog(
                    context: context,
                    builder: (context) => AlertDialog(
                      title: const Text("License Accepted"),
                      content: const Text(
                          "សូមអរគុណចំពោះការទទួលយកលក្ខខណ្ឌនៃកិច្ចព្រមព្រៀងអាជ្ញាប័ណ្ណ។.", 
                            style: TextStyle(
                              color: Colors.black,
                              fontWeight: FontWeight.w100,
                              
                            ),
                          ),
                      actions: [
                        TextButton(
                          onPressed: () {
                            Navigator.pop(context);
                          },
                          child: const Text("Close"),
                        ),
                      ],
                    ),
                  );
                },
                child: const Text(
                  "Accept License",
                  style: TextStyle(fontSize: 16, color: Colors.white),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
