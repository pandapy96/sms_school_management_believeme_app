import 'package:flutter/material.dart';

class Termsofservice extends StatelessWidget {
  const Termsofservice({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: const Color.fromARGB(255, 255, 255, 255)),
        title: const Text("Terms of Service",
          style: TextStyle(
            color: Colors.white,
          ),
        ),
        backgroundColor: Colors.blue,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Title
            const Text(
              "Terms of Service",
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.blue,
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              "Lead Professor: Rin Tino",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            // Developer Info
            const Text(
              "Developer: Nou Sivyang",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const Text(
              "Collaborate: Brach Sida",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const Text(
              "Sponsored by School: Believe in Me School",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),

            // License Terms
            const Text(
              "Terms and Conditions",
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.blue,
              ),
            ),
            const SizedBox(height: 10),
            Expanded(
              child: SingleChildScrollView(
                child: const Text(
                  "1. This application is developed by Nou Sivyang for Believe in Me School.\n"
                  "2. You are granted a limited, non-exclusive license to use this application.\n"
                  "3. Redistribution, modification, or resale of this application without prior consent is prohibited.\n"
                  "4. The developer is not responsible for any damages resulting from improper use of this application.\n"
                  "5. By using this application, you agree to these terms and conditions.\n\n"
                  "Please read the above terms carefully before proceeding.",
                  style: TextStyle(fontSize: 16),
                ),
              ),
            ),

            const SizedBox(height: 20),

            // Action Buttons
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                // Decline Button
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.red,
                    padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 10),
                  ),
                  onPressed: () {
                    // Action when user declines
                    showDialog(
                      context: context,
                      builder: (context) => AlertDialog(
                        title: const Text("Terms Declined"),
                        content: const Text(
                            "You have declined the terms of service. The application cannot be used."),
                        actions: [
                          TextButton(
                            onPressed: () {
                              Navigator.pop(context);
                            },
                            child: const Text("Close"),
                          ),
                        ],
                      ),
                    );
                  },
                  child: const Text(
                    "Decline",
                    style: TextStyle(fontSize: 16, color: Colors.white),
                  ),
                ),

                // Accept Button
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green,
                    padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 10),
                  ),
                  onPressed: () {
                    // Action when user accepts
                    showDialog(
                      context: context,
                      builder: (context) => AlertDialog(
                        title: const Text("Terms Accepted"),
                        content: const Text(
                            "Thank you for accepting the terms of service. You can now use the application."),
                        actions: [
                          TextButton(
                            onPressed: () {
                              Navigator.pop(context);
                            },
                            child: const Text("Close"),
                          ),
                        ],
                      ),
                    );
                  },
                  child: const Text(
                    "Accept",
                    style: TextStyle(fontSize: 16, color: Colors.white),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
