import 'package:flutter/material.dart';


class Aboutdeverloperpage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.white),
        title: const Text("About Developer",
        style: TextStyle(
          color: Colors.white,
        ),
        ),
        backgroundColor: Colors.teal,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Developer's Name
              const Text(
                "Developer Information",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              const Text(
              "Lead Professor: Rin Tino In Build Bright Universe City of Branch Bantey Mean Chey ",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
              const SizedBox(height: 10),
              const Text(
                "Name: Nou Sivyang",
                style: TextStyle(fontSize: 18),
              ),
              const SizedBox(height: 10),
              const Text(
                "Contact: Nousivyang@gmail.com",
                style: TextStyle(fontSize: 18),
              ),
              const Text(
                "Developer Colleagues",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 10),
              const Text(
                "Name: Brach SiDa",
                style: TextStyle(fontSize: 18),
              ),
              const SizedBox(height: 10),
              const Text(
                "Contact: Brachsida@gmail.com",
                style: TextStyle(fontSize: 18),
              ),
              const SizedBox(height: 10),
              // Preface
              const Divider(),
              const Text(
                "Preface",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 10),
              const Text(
                "This application is developed by Nou Sivyang as part of a personal project to showcase Flutter development skills. "
                "It is designed to be user-friendly, feature-rich, and efficient. Feedback and suggestions are welcome to help improve this project.",
                style: TextStyle(fontSize: 18),
              ),
              const SizedBox(height: 20),

              // References
              const Divider(),
              const Text(
                "References",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 10),
              const Text(
                "1. Flutter Official Documentation - flutter.dev\n"
                "2. Figma Firbase And Flowchart And Data Statuce And Open AI And Google Flutter Assistance for improving code and UI/UX\n"
                "3. Contributions by Nou Sivyang and collaborators"
                "4. Facilitated by Professor Rintino of Build Bright University, Banteay Meanchey Branch.",
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 18,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
