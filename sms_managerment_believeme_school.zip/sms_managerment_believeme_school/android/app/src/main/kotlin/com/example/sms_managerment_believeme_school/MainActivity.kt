package com.example.sms_managerment_believeme_school

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
